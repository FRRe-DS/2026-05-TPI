// =====================================================================
// demo.js – Se ejecuta con:  npm start
//
//   PARTE 1: GraphQL – consulta anidada (viaje + conductor) en UNA petición HTTP.
//   PARTE 2: GraphQL frente a REST – tamaño de respuesta y tiempo.
//   PARTE 3: el PROBLEMA – dos cambios a la vez, SIN actor.
//   PARTE 4: la SOLUCIÓN – muchos cambios a la vez, por GraphQL y CON actor.
//
// Cada parte tiene comprobaciones (assert): si algo no da lo esperado,
// el programa se corta con un error. Los resultados no están escritos a mano.
// =====================================================================

import assert from 'node:assert/strict';
import { iniciarServidor } from './servidor.js';
import { contador } from './conductores.js';
import { Viaje } from './viaje.js';

// Levantamos el servidor de verdad, en un puerto libre, con tres viajes.
const app = await iniciarServidor(0, ['V1', 'V2', 'V3']);

// Hace una petición HTTP y devuelve el JSON recibido y cuántos bytes pesó.
async function pedir(ruta, cuerpo) {
  let opciones = { method: 'GET' };
  if (cuerpo) {
    opciones = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cuerpo),
    };
  }
  const respuesta = await fetch(app.url + ruta, opciones);
  const texto = await respuesta.text();
  return { datos: JSON.parse(texto), bytes: Buffer.byteLength(texto) };
}

function pedirGraphQL(consulta) {
  return pedir('/graphql', { query: consulta });
}

function titulo(texto) {
  console.log(`\n══════════ ${texto} ══════════\n`);
}

try {
  // -------------------------------------------------------------------
  titulo('PARTE 1: GraphQL, consulta anidada en UNA petición HTTP');

  contador.busquedas = 0;
  const a = await pedirGraphQL('{ viaje(id: "V1") { id estado } }');
  console.log('Consulta A (sin conductor):', JSON.stringify(a.datos));
  console.log('  Búsquedas de conductor:', contador.busquedas);
  assert.equal(contador.busquedas, 0);

  contador.busquedas = 0;
  const CONSULTA_ANIDADA = '{ viaje(id: "V1") { id estado conductor { nombre calificacion } } }';
  const b = await pedirGraphQL(CONSULTA_ANIDADA);
  console.log('\nConsulta B (con conductor):', JSON.stringify(b.datos));
  console.log('  Búsquedas de conductor:', contador.busquedas);
  assert.equal(contador.busquedas, 1);

  console.log('\n✔ El cliente eligió los campos. El conductor solo se buscó cuando se pidió.');

  // -------------------------------------------------------------------
  titulo('PARTE 2: GraphQL frente a REST (mismo dato: viaje + conductor)');

  // Este es el dato que las tres formas tienen que conseguir.
  const datoEsperado = b.datos.data.viaje;

  const formas = [
    {
      nombre: 'GraphQL',
      peticiones: 1,
      async obtener() {
        const r = await pedirGraphQL(CONSULTA_ANIDADA);
        return { dato: r.datos.data.viaje, bytes: r.bytes };
      },
    },
    {
      nombre: 'REST separado',
      peticiones: 2,
      async obtener() {
        const viaje = await pedir('/rest/viajes/V1');
        const conductor = await pedir('/rest/conductores/' + viaje.datos.conductorId);
        const dato = {
          id: viaje.datos.id,
          estado: viaje.datos.estado,
          conductor: { nombre: conductor.datos.nombre, calificacion: conductor.datos.calificacion },
        };
        return { dato, bytes: viaje.bytes + conductor.bytes };
      },
    },
    {
      nombre: 'REST agregado',
      peticiones: 1,
      async obtener() {
        const r = await pedir('/rest/detalle/V1');
        return { dato: r.datos, bytes: r.bytes };
      },
    },
  ];

  // Repetimos 21 veces, intercalando las tres formas para que ninguna tenga ventaja.
  const REPETICIONES = 21;
  const tiempos = { 'GraphQL': [], 'REST separado': [], 'REST agregado': [] };
  const bytes = {};

  for (let i = 0; i < REPETICIONES; i++) {
    for (const forma of formas) {
      const inicio = performance.now();
      const resultado = await forma.obtener();
      tiempos[forma.nombre].push(performance.now() - inicio);
      bytes[forma.nombre] = resultado.bytes;
      // Las tres tienen que traer exactamente el mismo dato útil.
      assert.deepEqual(resultado.dato, datoEsperado);
    }
  }

  // Mediana: ordenamos los 21 tiempos y tomamos el del medio (el número 11).
  function mediana(lista) {
    const ordenada = [...lista].sort((x, y) => x - y);
    return ordenada[Math.floor(ordenada.length / 2)];
  }

  console.table(formas.map((forma) => ({
    forma: forma.nombre,
    peticiones: forma.peticiones,
    'bytes de respuesta': bytes[forma.nombre],
    'tiempo mediano (ms)': Number(mediana(tiempos[forma.nombre]).toFixed(2)),
  })));

  assert.ok(bytes['GraphQL'] < bytes['REST separado']);
  console.log('✔ GraphQL trae lo mismo que REST separado en 1 petición y con menos bytes.');
  console.log('  Ojo: no es automáticamente más rápido. Un endpoint REST hecho a medida');
  console.log('  (REST agregado) puede ser igual de chico y más rápido. Son medidas locales.');

  // -------------------------------------------------------------------
  titulo('PARTE 3: el PROBLEMA, dos cambios a la vez SIN actor');

  const viajeSinActor = new Viaje('SIN-ACTOR', 'C1');
  // Promise.all lanza los dos pedidos al mismo tiempo, como dos personas distintas.
  const [r1, r2] = await Promise.all([
    viajeSinActor.finalizar(),
    viajeSinActor.cancelar('CAMBIO_DE_PLANES'),
  ]);

  console.log('Finalizar:', r1.mensaje);
  console.log('Cancelar :', r2.mensaje);
  console.log('Historial:', viajeSinActor.historial);
  assert.equal(r1.ok, true);
  assert.equal(r2.ok, true);

  console.log('\n✘ Los DOS fueron aceptados: el viaje se finalizó Y se canceló. Es un error.');

  // -------------------------------------------------------------------
  titulo('PARTE 4: la SOLUCIÓN, 10 cambios a la vez por GraphQL y CON actor');

  function mutacion(id, tipo) {
    if (tipo === 'FINALIZAR') {
      return `mutation { finalizarViaje(id: "${id}") { ok mensaje } }`;
    }
    return `mutation { cancelarViaje(id: "${id}", motivo: "CAMBIO_DE_PLANES") { ok mensaje } }`;
  }

  // Una ronda: 10 peticiones HTTP al mismo viaje, todas a la vez, alternando
  // finalizar y cancelar. Cambiamos cuál va primero para ver que puede ganar cualquiera.
  async function ronda(id, primero, segundo) {
    const tipos = [];
    for (let i = 0; i < 5; i++) {
      tipos.push(primero);
      tipos.push(segundo);
    }

    const peticiones = tipos.map((tipo) => pedirGraphQL(mutacion(id, tipo)));
    const respuestas = await Promise.all(peticiones);
    const resultados = respuestas.map((r) => Object.values(r.datos.data)[0]);
    const aceptados = resultados.filter((r) => r.ok).length;

    // Cómo quedó el viaje, preguntado por GraphQL.
    const final = await pedirGraphQL(`{ viaje(id: "${id}") { estado historial } }`);
    const viaje = final.datos.data.viaje;

    // Trazas: cuándo llegó, empezó y terminó cada mensaje (en ms desde el primero).
    const trazas = await app.actores.enviar(id, { tipo: 'TRAZAS' });
    const cero = trazas[0].llego;
    console.log(`Ronda en ${id} (primero se envió ${primero}):`);
    console.table(trazas.map((t) => ({
      mensaje: t.tipo,
      'llegó (ms)': Math.round(t.llego - cero),
      'empezó (ms)': Math.round(t.empezo - cero),
      'terminó (ms)': Math.round(t.termino - cero),
      resultado: t.ok ? 'ACEPTADO' : 'rechazado',
    })));
    console.log(`Aceptados: ${aceptados} de ${tipos.length}  |  Estado final: ${viaje.estado}  |  Historial: ${JSON.stringify(viaje.historial)}\n`);

    // Comprobaciones:
    // 1) Solo un cambio aceptado y un solo evento en el historial.
    assert.equal(aceptados, 1);
    assert.equal(viaje.historial.length, 1);
    // 2) De a uno: ningún mensaje empezó antes de que terminara el anterior.
    for (let i = 1; i < trazas.length; i++) {
      assert.ok(trazas[i].empezo >= trazas[i - 1].termino);
    }
    // 3) Hubo cola: algún mensaje llegó mientras el actor seguía atendiendo otro.
    const esperaron = trazas.filter((t, i) => i > 0 && t.llego < trazas[i - 1].termino);
    assert.ok(esperaron.length > 0);
  }

  await ronda('V2', 'FINALIZAR', 'CANCELAR');
  await ronda('V3', 'CANCELAR', 'FINALIZAR');

  console.log('✔ En cada ronda, los mensajes llegaron casi juntos pero esperaron en el buzón');
  console.log('  y se atendieron de a uno: 1 aceptado y 9 rechazados, sin usar locks.');

  console.log('\n✔ TODAS LAS COMPROBACIONES PASARON\n');
} finally {
  app.cerrar();
}
