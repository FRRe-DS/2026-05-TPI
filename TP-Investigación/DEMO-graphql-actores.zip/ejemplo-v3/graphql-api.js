// =====================================================================
// graphql-api.js – GraphQL con la librería graphql (graphql-js).
//
// Dos partes:
//   A) El ESQUEMA: el "menú" de qué se puede pedir y qué se puede hacer.
//   B) Los RESOLVERS: funciones que dicen cómo conseguir cada dato.
//
// Los resolvers NO tocan el viaje: le mandan un MENSAJE a su actor.
//   GraphQL decide QUÉ datos se piden; el actor decide QUÉ cambios se aceptan.
// =====================================================================

import { buildSchema, graphql } from 'graphql';
import { buscarConductor } from './conductores.js';

// ---------- A) EL ESQUEMA ----------
const esquema = buildSchema(`
  type Conductor {
    nombre: String!
    calificacion: Float!
  }

  type Viaje {
    id: ID!
    estado: String!
    historial: [String!]!
    conductor: Conductor
  }

  type Resultado {
    ok: Boolean!
    mensaje: String!
  }

  type Query {
    viaje(id: ID!): Viaje
  }

  type Mutation {
    finalizarViaje(id: ID!): Resultado!
    cancelarViaje(id: ID!, motivo: String!): Resultado!
  }
`);

// ---------- B) LOS RESOLVERS ----------
function crearResolvers(actores) {
  return {
    async viaje({ id }) {
      if (!actores.existe(id)) {
        return null;
      }
      const viaje = await actores.enviar(id, { tipo: 'CONSULTAR' });

      // El conductor queda como FUNCIÓN: GraphQL solo la ejecuta
      // si el cliente pidió el campo "conductor". Si no lo pidió, no se busca.
      viaje.conductor = () => buscarConductor(viaje.conductorId);
      return viaje;
    },

    finalizarViaje({ id }) {
      return actores.enviar(id, { tipo: 'FINALIZAR' });
    },

    cancelarViaje({ id, motivo }) {
      return actores.enviar(id, { tipo: 'CANCELAR', motivo });
    },
  };
}

// Devuelve una función que recibe el texto de una consulta GraphQL y la ejecuta.
export function crearAPI(actores) {
  const resolvers = crearResolvers(actores);
  return (consulta) => graphql({ schema: esquema, source: consulta, rootValue: resolvers });
}
