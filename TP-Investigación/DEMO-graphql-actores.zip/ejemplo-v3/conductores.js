// =====================================================================
// conductores.js – Catálogo de conductores, guardado APARTE del viaje.
//
// Así, para dar los datos del conductor hay que BUSCARLOS a propósito.
// El contador sirve para comprobar que GraphQL solo los busca
// cuando el cliente los pide.
// =====================================================================

const conductores = new Map();
conductores.set('C1', {
  id: 'C1',
  nombre: 'Ana',
  calificacion: 4.8,
  vehiculo: 'Sedán',
  patente: 'AB123CD',
});

export const contador = { busquedas: 0 };

export function buscarConductor(id) {
  contador.busquedas++;
  return conductores.get(id) ?? null;
}
