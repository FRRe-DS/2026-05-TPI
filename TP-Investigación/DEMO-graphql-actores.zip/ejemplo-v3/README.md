# GraphQL + Modelo de Actores

Grupo 5 · Desarrollo de Software · UTN 2026 · Temas 31 y 32

Un viaje en curso. El conductor aprieta "finalizar" y el pasajero aprieta "cancelar" al mismo tiempo. Un viaje no puede terminar de las dos formas. El ejemplo muestra cómo GraphQL sirve para consultar el viaje y cómo un actor evita que dos cambios se pisen.

## Cómo correrlo

Necesita Node.js 22 o más (`node -v` para ver la versión).

```bash
npm install
npm start
```

`npm start` levanta un servidor HTTP local, hace todas las peticiones, muestra los resultados y se cierra solo. Si alguna comprobación falla, el programa termina con error. Si todo está bien, termina con `TODAS LAS COMPROBACIONES PASARON`.

Para guardar la salida como evidencia: `npm run evidencia` (crea `evidencia.txt`).

## Qué muestra cada parte

| Parte | Qué demuestra | Comprobación |
|---|---|---|
| 1. GraphQL | Consulta anidada (viaje + conductor) en **una sola petición HTTP**. El conductor solo se busca si el cliente lo pide. | 0 búsquedas sin pedirlo, 1 pidiéndolo |
| 2. GraphQL frente a REST | El mismo dato pedido de tres formas: cantidad de peticiones, bytes de respuesta y tiempo mediano. | Las tres traen el mismo dato; GraphQL pesa menos que REST separado |
| 3. Sin actor | El problema: finalizar y cancelar a la vez, los dos son aceptados. | 2 aceptados |
| 4. Con actor | 10 mutations HTTP a la vez sobre el mismo viaje, en dos rondas. La tabla muestra cuándo **llegó**, **empezó** y **terminó** cada mensaje. | 1 aceptado y 9 rechazados; ninguno empieza antes de que termine el anterior; algunos esperaron en la cola |

Cómo leer la tabla de la Parte 4: todos los mensajes **llegan** en los primeros milisegundos, pero el segundo recién **empieza** cuando termina el primero (alrededor de 100 ms después). Ese tiempo es el que pasó esperando en el buzón. En la ronda 1 se envía primero finalizar y en la ronda 2 primero cancelar: gana el que el actor atiende primero.

## Archivos

| Archivo | Qué hace |
|---|---|
| `viaje.js` | El viaje y sus reglas (validar, guardar, cambiar). Solo, no se protege. |
| `conductores.js` | Los datos de los conductores, guardados aparte del viaje. |
| `actor.js` | Un actor Nact por viaje. Atiende los mensajes de a uno y anota las trazas. |
| `graphql-api.js` | Esquema y resolvers. Los resolvers le mandan mensajes al actor. |
| `servidor.js` | Servidor HTTP: `POST /graphql` y las rutas REST. |
| `demo.js` | Hace las peticiones, muestra los resultados y las comprueba. |

Recorrido de un cambio: **petición HTTP → GraphQL → resolver → mensaje al actor → buzón → el actor cambia el viaje → respuesta**.

Dependencias: `graphql` (GraphQL) y `nact` (actores). Nada más.

## ¿Dónde está el buzón?

Dentro de Nact. En `node_modules/nact/lib/actor.js`:

- `dispatch`: si el actor está ocupado (`busy`), el mensaje va al buzón (`mailbox`).
- `handleMessage`: espera (`await`) a que termine `atenderMensaje` antes de seguir.
- `processNext`: recién entonces saca el siguiente mensaje del buzón.

Por eso no hacen falta locks: nunca se ejecutan dos mensajes del mismo viaje a la vez.

## Prueba para el coloquio

En `actor.js`, borrá las dos palabras `await` de `atenderMensaje` y corré `npm start` otra vez. El actor ya no espera a que termine cada cambio, y en la Parte 4 se aceptan 10 de 10: la demo termina con error. Eso muestra que la consistencia viene de procesar los mensajes de a uno.

## Probar a mano (Postman)

```bash
npm run server
```

Queda escuchando en `http://127.0.0.1:4000` (Ctrl+C para cerrar). Enviar `POST /graphql` con cabecera `Content-Type: application/json` y uno de estos cuerpos:

```json
{"query":"{ viaje(id:\"V1\") { id estado conductor { nombre calificacion } } }"}
{"query":"mutation { finalizarViaje(id:\"V1\") { ok mensaje } }"}
{"query":"mutation { cancelarViaje(id:\"V1\", motivo:\"CAMBIO_DE_PLANES\") { ok mensaje } }"}
```

Rutas REST (GET): `/rest/viajes/V1`, `/rest/conductores/C1`, `/rest/detalle/V1`. Reiniciar el servidor vuelve el viaje a `IN_PROGRESS`.

## Límites

- Los datos son de ejemplo y la "base de datos" es una espera de 100 ms.
- Todo vive en memoria: al cerrar el programa se pierde.
- El actor protege dentro de un solo proceso. Con varias instancias del servidor haría falta control en la base de datos (por ejemplo, un número de versión).
- GraphQL no es automáticamente más rápido: ahorra datos de más, pero un endpoint REST hecho a medida puede ser más rápido. Los tiempos son locales y cambian entre corridas.
