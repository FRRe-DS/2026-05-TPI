// =====================================================================
// servidor.js – Servidor HTTP con las dos formas de pedir datos:
//
//   GraphQL:  POST /graphql             (UNA ruta; el cliente dice qué quiere)
//   REST:     GET  /rest/viajes/V1      (rutas fijas; cada una devuelve
//             GET  /rest/conductores/C1  siempre la misma forma)
//             GET  /rest/detalle/V1     (REST "agregado": viaje + conductor juntos)
// =====================================================================

import http from 'node:http';
import { crearActores } from './actor.js';
import { crearAPI } from './graphql-api.js';
import { buscarConductor } from './conductores.js';

function responder(res, datos, codigo = 200) {
  res.writeHead(codigo, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(datos));
}

async function leerCuerpo(req) {
  let texto = '';
  for await (const parte of req) {
    texto += parte;
  }
  return JSON.parse(texto);
}

export async function iniciarServidor(puerto, idsDeViajes) {
  const actores = crearActores(idsDeViajes);
  const ejecutarGraphQL = crearAPI(actores);

  const servidor = http.createServer(async (req, res) => {
    try {
      // Ejemplo: "/rest/viajes/V1"  →  ['', 'rest', 'viajes', 'V1']
      const [, raiz, recurso, id] = req.url.split('/');

      // ---------- GraphQL ----------
      if (req.method === 'POST' && raiz === 'graphql') {
        const { query } = await leerCuerpo(req);
        const resultado = await ejecutarGraphQL(query);
        return responder(res, resultado);
      }

      // ---------- REST ----------
      if (req.method === 'GET' && raiz === 'rest') {
        if (recurso === 'viajes' && actores.existe(id)) {
          const viaje = await actores.enviar(id, { tipo: 'CONSULTAR' });
          return responder(res, viaje);
        }

        if (recurso === 'conductores' && buscarConductor(id)) {
          return responder(res, buscarConductor(id));
        }

        if (recurso === 'detalle' && actores.existe(id)) {
          // Endpoint hecho a medida para esta pantalla: ya junta viaje + conductor.
          const viaje = await actores.enviar(id, { tipo: 'CONSULTAR' });
          const conductor = buscarConductor(viaje.conductorId);
          return responder(res, {
            id: viaje.id,
            estado: viaje.estado,
            conductor: { nombre: conductor.nombre, calificacion: conductor.calificacion },
          });
        }
      }

      responder(res, { error: 'Ruta inexistente' }, 404);
    } catch (error) {
      // Por ejemplo, si el cuerpo no es un JSON válido.
      responder(res, { error: error.message }, 400);
    }
  });

  // Puerto 0 = el sistema elige uno libre (lo usa la demo).
  await new Promise((listo) => servidor.listen(puerto, '127.0.0.1', listo));

  return {
    url: `http://127.0.0.1:${servidor.address().port}`,
    actores,
    cerrar() {
      servidor.closeAllConnections();
      servidor.close();
      actores.cerrar();
    },
  };
}

// Con "npm run server" queda escuchando en el puerto 4000, para probar con Postman.
if (process.argv[1].endsWith('servidor.js')) {
  const { url } = await iniciarServidor(4000, ['V1']);
  console.log(`Servidor escuchando en ${url}  (Ctrl+C para cerrar)`);
}
