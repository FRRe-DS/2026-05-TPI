// =====================================================================
// viaje.js – El viaje y sus reglas de negocio.
//
// Esta clase NO se protege sola: si dos pedidos la tocan a la vez,
// los dos pueden pasar la validación. Por eso, en la aplicación,
// solo el ACTOR (actor.js) la modifica.
// =====================================================================

export function esperar(ms) {
  return new Promise((resolver) => setTimeout(resolver, ms));
}

export class Viaje {
  constructor(id, conductorId) {
    this.id = id;
    this.conductorId = conductorId; // el viaje solo guarda el id; los datos del conductor están aparte
    this.estado = 'IN_PROGRESS';
    this.origen = 'Terminal';
    this.destino = 'Centro';
    this.historial = [];
  }

  finalizar() {
    return this.cambiarEstado('COMPLETED', 'finalizado');
  }

  cancelar(motivo) {
    return this.cambiarEstado('CANCELLED', `cancelado (${motivo})`);
  }

  async cambiarEstado(nuevoEstado, evento) {
    // 1) VALIDAR: solo un viaje en curso puede terminar.
    if (this.estado !== 'IN_PROGRESS') {
      return { ok: false, mensaje: `Rechazado: el viaje ya está ${this.estado}` };
    }

    // 2) GUARDAR: simulamos 100 ms de escritura (no hay base de datos real).
    //    Mientras se espera acá, Node puede atender otro pedido.
    await esperar(100);

    // 3) CAMBIAR
    this.estado = nuevoEstado;
    this.historial.push(evento);
    return { ok: true, mensaje: `Aceptado: el viaje quedó ${nuevoEstado}` };
  }

  // Devuelve una COPIA: quien la reciba no puede modificar el viaje real.
  copia() {
    return {
      id: this.id,
      conductorId: this.conductorId,
      estado: this.estado,
      origen: this.origen,
      destino: this.destino,
      historial: [...this.historial],
    };
  }
}
