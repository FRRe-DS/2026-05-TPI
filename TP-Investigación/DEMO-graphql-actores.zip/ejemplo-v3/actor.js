// =====================================================================
// actor.js – Modelo de Actores con la librería Nact.
//
// Cada viaje tiene SU actor, que es el único dueño de su estado.
// Nact le da a cada actor un BUZÓN: los mensajes que llegan esperan ahí
// y el actor los atiende DE A UNO. No le pasa el siguiente mensaje hasta
// que termina el anterior, incluida la espera de 100 ms.
// Por eso no hacen falta locks: nunca hay dos cambios a la vez.
// =====================================================================

import nact from 'nact';
import { Viaje } from './viaje.js';

const { start, spawn, query, dispatch, stop } = nact;

// Qué hace el actor con UN mensaje. Nact la llama una vez por mensaje, en orden.
async function atenderMensaje(estado, mensaje, contexto) {
  if (mensaje.tipo === 'CONSULTAR') {
    dispatch(contexto.sender, estado.viaje.copia());
    return estado;
  }

  if (mensaje.tipo === 'TRAZAS') {
    dispatch(contexto.sender, [...estado.trazas]);
    return estado;
  }

  // FINALIZAR o CANCELAR: los únicos mensajes que modifican el viaje.
  const empezo = performance.now();
  let respuesta;
  if (mensaje.tipo === 'FINALIZAR') {
    respuesta = await estado.viaje.finalizar();
  } else {
    respuesta = await estado.viaje.cancelar(mensaje.motivo);
  }
  const termino = performance.now();

  // Anotamos cuándo llegó, cuándo empezó y cuándo terminó cada mensaje,
  // para poder DEMOSTRAR que esperó en la cola y que se atendió de a uno.
  estado.trazas.push({
    tipo: mensaje.tipo,
    llego: mensaje.llego,
    empezo,
    termino,
    ok: respuesta.ok,
  });

  dispatch(contexto.sender, respuesta); // le contesto a quien mandó el mensaje
  return estado; // el estado (ya actualizado) queda guardado para el próximo mensaje
}

// Crea un actor por cada viaje.
export function crearActores(idsDeViajes) {
  const sistema = start();
  const actores = new Map();

  for (const id of idsDeViajes) {
    const estadoInicial = { viaje: new Viaje(id, 'C1'), trazas: [] };
    const actor = spawn(sistema, atenderMensaje, id, { initialState: estadoInicial });
    actores.set(id, actor);
  }

  return {
    existe(id) {
      return actores.has(id);
    },

    // Única forma de hablar con un viaje: mandarle un mensaje a su actor
    // y esperar la respuesta (hasta 5 segundos).
    enviar(id, mensaje) {
      const mensajeConHora = { ...mensaje, llego: performance.now() };
      return query(actores.get(id), mensajeConHora, 5000);
    },

    cerrar() {
      stop(sistema);
    },
  };
}
